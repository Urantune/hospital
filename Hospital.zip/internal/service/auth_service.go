package service

import (
	"errors"
	"fmt"
	"time"

	"hospital/internal/models"
	"hospital/internal/repository"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

var jwtSecret = []byte("supersecret")

func Register(email, password string) (*models.User, error) {

	_, err := repository.GetUserByEmail(email)
	if err == nil {
		return nil, errors.New("email already exists")
	}

	hash, _ := bcrypt.GenerateFromPassword([]byte(password), 12)

	user := &models.User{
		ID:                uuid.New().String(),
		Email:             email,
		PasswordHash:      string(hash),
		VerificationToken: uuid.New().String(),
		Status:            "active",
	}

	err = repository.CreateUser(user)
	return user, err
}

func Verify(token string) error {
	return repository.VerifyUser(token)
}

func Login(email, password string) (string, string, error) {

	user, err := repository.GetUserByEmail(email)
	if err != nil {
		return "", "", errors.New("invalid credentials")
	}

	if !user.IsVerified {
		return "", "", errors.New("account not verified")
	}

	err = bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(password))
	if err != nil {
		return "", "", errors.New("invalid credentials")
	}

	accessToken := generateJWT(user.ID)
	refreshToken := uuid.New().String()

	repository.SaveRefreshToken(user.ID, refreshToken)
	fmt.Println("EMAIL:", email)
	fmt.Println("PASSWORD INPUT:", password)
	fmt.Println("HASH FROM DB:", user.PasswordHash)
	return accessToken, refreshToken, nil
}

func generateJWT(userID string) string {

	claims := jwt.MapClaims{
		"user_id": userID,
		"exp":     time.Now().Add(time.Hour).Unix(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, _ := token.SignedString(jwtSecret)
	return signed
}
