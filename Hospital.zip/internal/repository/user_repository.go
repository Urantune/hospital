package repository

import (
	"errors"
	"hospital/internal/config"
	"hospital/internal/models"
)

func CreateUser(user *models.User) error {

	query := `
	INSERT INTO users 
	(id, email, password_hash, verification_token, is_verified, status, created_at, updated_at)
	VALUES (@p1, @p2, @p3, @p4, @p5, @p6, GETDATE(), GETDATE())
	`

	_, err := config.DB.Exec(
		query,
		user.ID,
		user.Email,
		user.PasswordHash,
		user.VerificationToken,
		user.IsVerified,
		user.Status,
	)

	return err
}

func GetUserByEmail(email string) (*models.User, error) {

	var user models.User

	query := `SELECT * FROM users WHERE email = @p1`

	err := config.DB.Get(&user, query, email)

	return &user, err
}

func VerifyUser(token string) error {

	query := `
	UPDATE users
	SET is_verified = 1,
	    verification_token = NULL,
	    updated_at = GETDATE()
	WHERE verification_token = @p1
	`

	result, err := config.DB.Exec(query, token)
	if err != nil {
		return err
	}

	rows, _ := result.RowsAffected()
	if rows == 0 {
		return errors.New("invalid token")
	}

	return nil
}

func SaveRefreshToken(userID, token string) error {

	query := `
	INSERT INTO refresh_tokens 
	(user_id, refresh_token, expires_at, created_at)
	VALUES (@p1, @p2, DATEADD(DAY, 7, GETDATE()), GETDATE())
	`

	_, err := config.DB.Exec(query, userID, token)

	return err
}
