package handler

import (
	"net/http"

	"hospital/internal/service"

	"github.com/gin-gonic/gin"
)

type RegisterRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func Register(c *gin.Context) {

	var req RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	user, err := service.Register(req.Email, req.Password)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{
		"message":      "User registered. Verify account.",
		"verify_token": user.VerificationToken,
	})
}

func Verify(c *gin.Context) {

	token := c.Query("token")
	err := service.Verify(token)

	if err != nil {
		c.JSON(400, gin.H{"error": "invalid token"})
		return
	}

	c.JSON(200, gin.H{"message": "Account verified"})
}

func Login(c *gin.Context) {

	var req RegisterRequest

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	access, refresh, err := service.Login(req.Email, req.Password)
	if err != nil {
		c.JSON(401, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{
		"access_token":  access,
		"refresh_token": refresh,
	})
}
