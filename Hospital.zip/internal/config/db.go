package config

import (
	"log"

	_ "github.com/denisenkom/go-mssqldb"
	"github.com/jmoiron/sqlx"
)

var DB *sqlx.DB

func ConnectDB() {

	dsn := "sqlserver://sa:123456@localhost:1433?database=Hospital"

	db, err := sqlx.Connect("sqlserver", dsn)
	if err != nil {
		log.Fatal("DB connection failed:", err)
	}

	DB = db
}
