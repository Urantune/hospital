package main

import (
	"hospital/internal/config"
	"hospital/internal/handler"

	"github.com/gin-gonic/gin"
)

func main() {

	config.ConnectDB()

	r := gin.Default()

	r.POST("/register", handler.Register)
	r.GET("/verify", handler.Verify)
	r.POST("/login", handler.Login)

	r.Run(":8080")
}
